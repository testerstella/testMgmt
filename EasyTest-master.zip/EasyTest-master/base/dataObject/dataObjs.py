
class contentObj:
    if_id = ""
    if_name = ""
    header = {}
    body = {}
    extract = {}
    validator = {}
